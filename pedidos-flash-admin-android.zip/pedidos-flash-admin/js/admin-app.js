if (typeof tailwind !== "undefined") {
  tailwind.config = {
    theme: {
      extend: {
        fontFamily: {
          sans: ["Plus Jakarta Sans", "sans-serif"],
          orbitron: ["Orbitron", "sans-serif"]
        },
        colors: {
          brand: { 500: "#6366f1", 600: "#4f46e5", 700: "#4338ca" },
          accent: {
            magenta: "#ff007a",
            cyan: "#00f2fe",
            orange: "#ff5e00",
            yellow: "#ffb800",
            emerald: "#00e676"
          }
        }
      }
    }
  };
}

function renderCatalogoAdmin() {
  const cont = document.getElementById("lista-catalogo-admin");
  if (!cont) return;
  const items = Object.values(window.CATALOGO_PRODU_TXT || {});
  if (!items.length) {
    cont.innerHTML = '<p class="text-xs text-slate-400">Sin productos cargados.</p>';
    return;
  }
  cont.innerHTML = items
    .map(
      (p) => `
      <div class="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
        <div>
          <p class="text-sm font-bold text-white">${p.nombre}</p>
          <p class="text-xs text-slate-400">${p.categoria} · ${p.sub || "General"}</p>
        </div>
        <span class="text-xs font-extrabold text-accent-cyan">$${Number(p.precioBase || 0).toFixed(2)}</span>
      </div>`
    )
    .join("");
}

function initTabsAdmin() {
  const buttons = document.querySelectorAll(".tab-btn");
  const panels = document.querySelectorAll(".tab-panel");
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.getAttribute("data-tab");
      buttons.forEach((b) => {
        b.classList.remove("bg-brand-600", "text-white");
        b.classList.add("bg-slate-800", "text-slate-300");
      });
      btn.classList.remove("bg-slate-800", "text-slate-300");
      btn.classList.add("bg-brand-600", "text-white");

      panels.forEach((panel) => {
        panel.classList.toggle("hidden", panel.id !== `panel-${target}`);
      });
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  if (typeof lucide !== "undefined") {
    lucide.createIcons();
  }
  const totalProds = Object.keys(window.CATALOGO_PRODU_TXT || {}).length;
  const badgeProds = document.getElementById("cant-admin-prods-badge");
  const metricaProds = document.getElementById("metrica-productos-total");
  if (badgeProds) badgeProds.textContent = totalProds;
  if (metricaProds) metricaProds.textContent = totalProds;
  initTabsAdmin();
  renderCatalogoAdmin();
});
