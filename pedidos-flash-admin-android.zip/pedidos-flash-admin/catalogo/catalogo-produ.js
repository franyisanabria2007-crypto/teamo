window.PRODUCTOS_BASE = window.PRODUCTOS_BASE || {};
window.productos = window.productos || {};

window.CATALOGO_PRODU_TXT = {
  "v_harina_blancaflor_1kg": {
    "id": "v_harina_blancaflor_1kg",
    "nombre": "Harina Blancaflor Leudante 1kg",
    "categoria": "viveres",
    "precioBase": 0,
    "badge": "",
    "sub": "Harinas",
    "imagen": "./img/v_harina_blancaflor_1kg.png",
    "esGranel": false
  }
};

Object.assign(window.PRODUCTOS_BASE, window.CATALOGO_PRODU_TXT);
Object.assign(window.productos, window.CATALOGO_PRODU_TXT);
